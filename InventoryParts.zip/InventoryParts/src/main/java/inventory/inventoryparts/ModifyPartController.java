package inventory.inventoryparts;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/** Controller which provides logic control for
 * modify part screen.
 *
 * @author jacil Perez
 * */
public class ModifyPartController implements Initializable {


    private int  index;








    @FXML
    private TextField IDTxtField;

    @FXML
    private RadioButton InHouseBtn;

    @FXML
    private TextField InvTextField;

    @FXML
    private TextField MachineIDTXTFIeld;

    @FXML
    private TextField MaxTxtField;

    @FXML
    private TextField MinTxtField;

    @FXML
    private TextField NameTxtField;

    @FXML
    private RadioButton OutsourcedBtn;

    @FXML
    private TextField PriceCostField;
    private Stage stage;
    private Parent scene;
    @FXML
    private Label MachineIDorCompanyName;
    private boolean InHouse;
    private boolean Outsourced;

    /** Cancel button which lands user back to the main screen.
     *
     * @param event cancel button action.
     * @throws IOException loads FXMLloader.
     * */
    @FXML
    void OnActionCancelBtn(ActionEvent event) throws IOException {
        this.stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        this.scene = (Parent) FXMLLoader.load(this.getClass().getResource("MainScreen.fxml"));
        this.stage.setScene(new Scene(this.scene));
        this.stage.show();

    }
    /** Modifies part with updated values.
     * Returns user to the main screen.
     *
     * @param event Save button for modify part table.
     * @throws IOException loads FXMLloader.
     * */
    @FXML
    void OnActionSaveBtn(ActionEvent event) throws IOException {
        try {
            int ID = Integer.parseInt(IDTxtField.getText());
            int Inv = Integer.parseInt(InvTextField.getText());

            String Name = NameTxtField.getText();
            double Price = Double.parseDouble(PriceCostField.getText());
            int min = Integer.parseInt(MinTxtField.getText());
            int max = Integer.parseInt(MaxTxtField.getText());

            int machineID;
            String CompanyName;

            if(max < min && Inv < min || Inv > max) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Inventory Error");
                alert.setContentText("Inventory amount must be within maximum and minimum range!");
                alert.showAndWait();
                return;


            }


            if(InHouseBtn.isSelected()) {
                machineID = Integer.parseInt(MachineIDTXTFIeld.getText());
                Part part = new InHouse(ID, Name, Price, Inv, min, max, machineID);
                Inventory.updatePart(index, part);


            }
            else {
                CompanyName = MachineIDTXTFIeld.getText();
                Part part = new Outsourced(ID, Name, Price, Inv, min, max, CompanyName);
                Inventory.updatePart(index, part);
            }




            this.stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            this.scene = (Parent)FXMLLoader.load(this.getClass().getResource("MainScreen.fxml"));
            this.stage.setScene(new Scene(this.scene));
            this.stage.show();

        }
        catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("please enter a valid value for each text Field!");
            alert.showAndWait();
        }


    }
    /** Changes label name to Machine ID when InHouse
     * button is selected.
     *
     * @param event InHouse radio button.
     * */
    public void OnActionInHouse(ActionEvent event) {
        MachineIDorCompanyName.setText("Machine ID");
         InHouse = true;
    }
    /** Changes label name to Company name when Outsourced
     * button is selected.
     *
     * @param event Outsourced radio button.
     * */
    public void OnActionOutsourced(ActionEvent event) {
        MachineIDorCompanyName.setText("Company Name");
    }
    /** Variable for machineID or Company name label.
     * @param machineIDorCompanyName label name for Inhouse or Outhouse part.
     *
     * */
    public void setMachineIDorCompanyName(Label machineIDorCompanyName) {
        MachineIDorCompanyName = machineIDorCompanyName;
    }
    /** Initializer for modify part controller
     *
     * @param resourceBundle resources used for root object.
     * @param url location of root object.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
    /** Populates each text field with the selected
     * parts values.
     *
     * @param selectedPart part selected.
     * @param index Index number of part selected.
     * */
    public void getSelectedPart (Part selectedPart, int index) {


    this.index = index;


        IDTxtField.setText(String.valueOf(selectedPart.getId()));
        NameTxtField.setText(selectedPart.getName());
        PriceCostField.setText(String.valueOf(selectedPart.getPrice()));
        MinTxtField.setText(String.valueOf(selectedPart.getMin()));
        MaxTxtField.setText(String.valueOf(selectedPart.getMax()));
        InvTextField.setText(String.valueOf(selectedPart.getStock()));


        if(selectedPart instanceof Outsourced) {
            MachineIDTXTFIeld.setText(((Outsourced) selectedPart).getCompanyName());
            OutsourcedBtn.setSelected(true);
            MachineIDorCompanyName.setText("Company Name");

        }

        if(selectedPart instanceof InHouse) {
            MachineIDTXTFIeld.setText(String.valueOf(((InHouse) selectedPart).getMachineId()));
            MachineIDorCompanyName.setText("MachineID");
        }



    }

}