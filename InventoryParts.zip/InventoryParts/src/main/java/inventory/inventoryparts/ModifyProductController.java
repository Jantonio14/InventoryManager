package inventory.inventoryparts;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/** Controller for Modify product screen.
 *
 * @author Jacil Perez
 **/
public class ModifyProductController implements Initializable {
    private int index;
    Product product;

    private ObservableList<Part> partsAssociated = FXCollections.observableArrayList();

    @FXML
    private TableView<Part> tableView1;

    @FXML
    private TableColumn<Part, Integer> partIDCol;

    @FXML
    private TableColumn<Part, String> partNameCol;

    @FXML
    private TableColumn<Part, Integer> invCol;

    @FXML
    private TableColumn<Part, Double> priceCol;



    @FXML
    private TableView<Part> tableView2;

    @FXML
    private TableColumn<Part, Integer> partIdCol2;

    @FXML
    private TableColumn<Part, String> partNameCol2;

    @FXML
    private TableColumn<Part, Integer> invCol2;

    @FXML
    private TableColumn<Part, Double> priceCol2;



    @FXML
    private TextField ModifyInvFieldTxt;

    @FXML
    private TextField ModifyProductIDTxt;

    @FXML
    private TextField ModifyProductMaxTxt;

    @FXML
    private TextField ModifyProductMinTxt;

    @FXML
    private TextField ModifyProductPriceFieldTxt;

    @FXML
    private TextField ModifyProductSearchTxt;

    @FXML
    private TextField NameProductNameTxt;
    private Stage stage;
    private Parent scene;

    /** Cancel button which lands user back to the main screen.
     *
     * @param event cancel button action.
     * @throws IOException loads FXMLloader.
     * */
    @FXML
    void OnActionCancelProduct2(ActionEvent event) throws IOException {
        this.stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        this.scene = (Parent) FXMLLoader.load(this.getClass().getResource("MainScreen.fxml"));
        this.stage.setScene(new Scene(this.scene));
        this.stage.show();

    }
    /** Adds selected part to associated parts list
     *
     * If no part is selected an error message is displayed.
     * @param event add selected part button.
     * */
    @FXML
    void OnActionAddBtn(ActionEvent event) {
        Part partSelected = tableView1.getSelectionModel().getSelectedItem();
        product.addAssociatedParts(partSelected);

        if (partSelected == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("please select a value!");
            alert.showAndWait();
        } else {
            //  partsAssociated.add(partSelected);
            tableView2.setItems(product.getAllAssociatedParts());
        }


    }
    /** Removes selected part from associated parts
     * table.
     *
     * An error message is displayed if no part is selected.
     * @param event  remove associated part button.
     * */
    @FXML
    void OnActionRemovePart2(ActionEvent event) {
        Part partSelected = tableView2.getSelectionModel().getSelectedItem();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Warning");
        alert.setContentText("Remove Associated part?");
        Optional<ButtonType> res = alert.showAndWait();


        if (res.isPresent() && res.get() == ButtonType.OK) {
//            partsAssociated.remove(partSelected);
//            //  partsAssociated.remove(partSelected);
//            tableView2.setItems(partsAssociated);
//            partIdCol2.setCellValueFactory(new PropertyValueFactory<>("id"));
//            partNameCol2.setCellValueFactory(new PropertyValueFactory<>("name"));
//            invCol2.setCellValueFactory(new PropertyValueFactory<>("stock"));
//            priceCol2.setCellValueFactory(new PropertyValueFactory<>("price"));
              product.deleteAssociatedPart(partSelected);
        }


    }

    /** Modifies product with updated values.
     * Returns user to the main screen.
     *
     * @param event Save button for modify product table.
     * @throws IOException loads FXMLloader.
     * */

    @FXML
    void OnActionSaveProduct2(ActionEvent event) throws IOException {

        try {
            int ID = Integer.parseInt(ModifyProductIDTxt.getText());
            int Inv = Integer.parseInt(ModifyInvFieldTxt.getText());

            String Name = NameProductNameTxt.getText();
            double Price = Double.parseDouble(ModifyProductPriceFieldTxt.getText());
            int min = Integer.parseInt(ModifyProductMinTxt.getText());
            int max = Integer.parseInt(ModifyProductMaxTxt.getText());

            Product product = new Product(ID, Name, Price, Inv, min, max);
            Inventory.updateProduct(index, product);
            for (Part part: partsAssociated) {
                if (part != partsAssociated)
                    product.addAssociatedParts(part);
            }


            if(max < min && Inv < min || Inv > max) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Inventory Error");
                alert.setContentText("Inventory amount must be within maximum and minimum range!");
                alert.showAndWait();
                return;


            }

            this.stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            this.scene = (Parent)FXMLLoader.load(this.getClass().getResource("MainScreen.fxml"));
            this.stage.setScene(new Scene(this.scene));
            this.stage.show();

        }
        catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("please enter a valid value for each text Field!");
            alert.showAndWait();
        }
    }
    /** Populates each text field with the selected
     * parts values.
     *
     * @param selectedProduct  product selected.
     * @param index Index number of product selected.
     * */
    public void getSelectedProduct (Product selectedProduct, int index) {
        product = selectedProduct;
        this.index = index;

        tableView1.setItems(Inventory.getAllParts());
        partIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        invCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));

        tableView2.setItems(selectedProduct.getAllAssociatedParts());
        partIdCol2.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol2.setCellValueFactory(new PropertyValueFactory<>("name"));
        invCol2.setCellValueFactory(new PropertyValueFactory<>("stock"));
        priceCol2.setCellValueFactory(new PropertyValueFactory<>("price"));


        ModifyProductIDTxt.setText(String.valueOf(product.getId()));
        NameProductNameTxt.setText(product.getName());
        ModifyProductPriceFieldTxt.setText(String.valueOf(product.getPrice()));
        ModifyProductMinTxt.setText(String.valueOf(product.getMin()));
        ModifyProductMaxTxt.setText(String.valueOf(product.getMax()));
        ModifyInvFieldTxt.setText(String.valueOf(product.getStock()));




    }
    /** Search products in text field by part name or product ID.
     * If no value is entered an error message will be displayed.
     *
     * @param event Products table search text field.
     * */
    @FXML
    void OnActionSearchBar3(ActionEvent event) {
        if (ModifyProductSearchTxt.getText().isEmpty()) {
            System.out.println("Tests");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Failed Search");
            alert.setContentText("Enter part name or the ID number before searching");
            alert.showAndWait();
        }


        try {


            tableView1.setItems(Inventory.getAllParts());
            int partId = Integer.parseInt(ModifyProductSearchTxt.getText());
            Part part = Inventory.lookupPart(partId);
            tableView1.getSelectionModel().select(part);
            String searchBox = ModifyProductSearchTxt.getText();


        }
        catch(Exception e) {
            String partName = ModifyProductSearchTxt.getText();
            ObservableList<Part> parts = Inventory.lookupPart(partName);
            tableView1.setItems(parts);
        }



    }
    /** Initializer for modify product controller.
     *
     * @param url location of root object.
     *
     * @param resourceBundle resources used for root object.
     * */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
