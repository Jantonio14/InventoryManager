package inventory.inventoryparts;

import javafx.collections.ObservableList;

import static javafx.collections.FXCollections.observableArrayList;

/** This class displays the products contained
 * within associated parts
 *
 * @author Jacil Perez
 * */

public class Product {

    private static ObservableList<Part> associatedParts = observableArrayList();

    private  int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    /** Constructor for product objects.
     *
     * @param id ID of product
     * @param name Name of product object
     * @param price price of product object
     * @param stock  Amount of stock of abject
     * @param min  minimum amount of stock
     * @param max  maximum amount of stock
     * */
    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }


    /** Getter for product ID.
     * @return id of product
     * */
    public int getId() {
        return id;
    }
    /**Setter for product ID.
     * @param id  ID of product.
     * */
    public void setId(int id) {
        this.id = id;
    }
    /**Getter for product name
     * @return name of product.
     * */
    public String getName() {
        return name;
    }
    /**Setter for product name.
     * @param name Name of product.
     * */
    public void setName(String name) {
        this.name = name;
    }
    /** Getter for price.
     * @return price of product.
     * */
    public double getPrice() {
        return price;
    }
    /**Setter for product price.
     * @param price Price of product.
     * */
    public void setPrice(double price) {
        this.price = price;
    }
    /**Getter for product stock.
     * @return stock Current stock of product.
     * */

    public int getStock() {
        return stock;
    }
    /** Setter for stock.
     * @param stock of product.
     * */
    public void setStock(int stock) {
        this.stock = stock;
    }
    /** Getter for product min.
     * @return min Mininum amount of stock.
     * */
    public int getMin() {
        return min;
    }
    /** Setter for min.
     * @param min Minimum amount of stock
     * */
    public void setMin(int min) {
        this.min = min;
    }
    /** Getter for max.
     * @return max Maximum amount of stock for product.
     * */
    public int getMax() {
        return max;
    }
    /** Setter for max.
     * @param max Maximum amount of stock.
     * */
    public void setMax(int max) {
        this.max = max;
    }
    /** This method adds a part for associated parts list for product class.
     *
     * @param part The part selected which will be added.
     *
     * */
    public void addAssociatedParts(Part part) {
        associatedParts.add(part);
    }
    /** Gets the list of associated parts from product.
     *
     * @return a list of parts.
     * */
    public ObservableList<Part> getAllAssociatedParts() {
        return associatedParts;
    }
    /** Removes a part from the associated parts list in the products class.
     *
     * @param selectedAssociatedPart selected part that will be removed.
     * @return status of part chosen to be removed.
     * */
    public boolean deleteAssociatedPart(Part selectedAssociatedPart) {
        associatedParts.remove(selectedAssociatedPart);
        return true;
    }
}