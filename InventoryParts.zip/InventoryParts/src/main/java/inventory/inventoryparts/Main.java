package inventory.inventoryparts;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/** Main class entends to application
 *
 * This application is an inventory management system.
 * This inventory consists of parts and products.
 *
 * FUTURE_ENHANCEMENT:
 * A new feature that should be implemented is a way to prevent associated parts from being duplicated within an associated
 * parts list.
 * @author jacil
 * */
public class Main extends Application {

    /** The start method initializes fxml file mainscreen.fxml
     * @param stage stage fxml
     *
     * */


    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("MainScreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 900, 500);
        stage.setTitle("Inventory Management");
        stage.setScene(scene);
        stage.show();
    }


    /**
     Main method contains test data and the launch for the application
     @param args args.
    */
    public static void main(String[] args) {

        Part bell = new InHouse( 1, "Bell", 10.00, 10, 4, 32, 1);
        Inventory.addPart(bell);

        Part wheel = new InHouse (2, "Wheel", 15.00, 16, 10, 30, 4);
        Inventory.addPart(wheel);

        Part chain = new InHouse (3 , "Chain", 40.00, 10, 0, 120, 5);
        Inventory.addPart(chain);

        Part spoke = new Outsourced(4,  "Spoke", 25.00, 10, 0, 120, "Bob's bikes");
        Inventory.addPart(spoke);

        Product SmallBike = new Product(1, "Small Bike", 299.99, 3, 1, 50);
        Inventory.addProduct(SmallBike);

        Product Scooter = new Product(2, "Scooter", 99.99, 5, 1, 50);
        Inventory.addProduct(Scooter);

        launch(args);
    }

}
