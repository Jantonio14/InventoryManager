package inventory.inventoryparts;

/**
 * InHouse class which extends part
 *
 * @author Jacil Perez
 * */

public class InHouse extends Part {
    private int machineId;

    /** Constructor for InHouse parts.
     *
     * @param id Id of part.
     * @param name name of inhouse part.
     * @param price price of inhouse part.
     * @param stock stock amount of inhouse part.
     * @param min minimum amount of stock for inhouse part.
     * @param max maximum amount of stock for inhouse part.
     * @param machineId MachinID of Inhouse part.
     * */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        super(id, name, price, stock, min, max);
        this.machineId = machineId;

    }

    /**
     * getter for machine ID
     * @return the machine ID
     */
    public int getMachineId() { return machineId; }

    /**
     * setter for machine ID
     * @param machineID the machine ID setter
     */
    public void setMachineId(int machineID) { this.machineId = machineId; }

}