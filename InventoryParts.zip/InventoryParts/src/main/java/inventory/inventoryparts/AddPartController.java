package inventory.inventoryparts;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
/**
 * This is a controller class for the Add Part screen of the application.
 *
 * @author Jacil Perez
 * */
public class AddPartController implements Initializable {

    /** autoID initialized to 5.
     *
     * */
    static int autoID = 5;

    @FXML
    private TextField IDTxtField;

    @FXML
    private RadioButton InHouseRdoBtn;

    @FXML
    private TextField InvTxtField;

    @FXML
    private TextField MachineIDTxtField;

    @FXML
    private TextField MaxTxtField;

    @FXML
    private TextField MinTxtField;

    @FXML
    private TextField NameTxtField;

    @FXML
    private RadioButton OutsourcedRdoBtn;

    @FXML
    private TextField PriceCostTxtField;

    @FXML
    private Label MachineIDorCompanyName;
    private Stage stage;
    private Parent scene;
    private boolean InHouse;

    /** Cancels out of the AddPart page and returns user to MainScreen.
     * @param event Cancel event handler.
     * @throws IOException from FxmlLoader.
     * */
    @FXML
    void OnActionCancelBtn(ActionEvent event) throws IOException {
        this.stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        this.scene = (Parent) FXMLLoader.load(this.getClass().getResource("MainScreen.fxml"));
        this.stage.setScene(new Scene(this.scene));
        this.stage.show();

    }
    /** Adds a new part to the part table.
     * Loads main screen
     *
     * Validation is included to prevent user from entering invalid values.
     * @param event add button.
     * @throws IOException
     * */
    @FXML
    void OnActionSaveBtn(ActionEvent event) throws IOException {
        try {
            int ID = autoID++;
            int Inv = Integer.parseInt(InvTxtField.getText());

            String Name = NameTxtField.getText();
            double Price = Double.parseDouble(PriceCostTxtField.getText());
            int min = Integer.parseInt(MinTxtField.getText());
            int max = Integer.parseInt(MaxTxtField.getText());

           int machineID = 0;
            String CompanyName;

            if(max < min && Inv < min || Inv > max) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Inventory Error");
                alert.setContentText("Inventory amount must be within maximum and minimum range!");
                alert.showAndWait();
                return;


            }


            if(InHouseRdoBtn.isSelected()) {
                 machineID = Integer.parseInt(MachineIDTxtField.getText());
                 Part part = new InHouse(ID, Name, Price, Inv, min, max, machineID);
                 Inventory.addPart(part);


            }
            else {
                CompanyName = MachineIDTxtField.getText();
                Part part = new Outsourced(ID, Name, Price, Inv, min, max, CompanyName);
                Inventory.addPart(part);
            }


            //    DataProvider.addAnimal(new Dog( id, breed, lifespan, behavior, price, isVaccinated, special));

            this.stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            this.scene = (Parent)FXMLLoader.load(this.getClass().getResource("MainScreen.fxml"));
            this.stage.setScene(new Scene(this.scene));
            this.stage.show();

        }
        catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("please enter a valid value for each text Field!");
            alert.showAndWait();
        }

    }
    /** Action event handler for radio button Inhouse.
     * @param event radio button Inhouse.
     * */
    @FXML
    public void OnActionInHouse1(ActionEvent event) {
        MachineIDorCompanyName.setText("Machine ID");


    }
    /** Action event handler for radio button Outsourced.
     * @param event radio button Outsourced.
     * */
    @FXML
    public void OnActionOutsourced1(ActionEvent event) {
        MachineIDorCompanyName.setText("Company Name");

    }
    /** Initializer for add part controller.
     *
     * @param url location of root object.
     * @param resourceBundle resources used for root object.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {



        }

}

