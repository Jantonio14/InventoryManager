package inventory.inventoryparts;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
/** Controller class that provides logic control for the main screen of
 * application.
 *
 * @author Jacil Perez
 * */
public class MainScreenController implements Initializable {

    @FXML
    private TextField PartsTxtFieldSearch;

    @FXML
    private TextField ProductsFieldTxtSearch;
    private Stage stage;
    private Parent scene;

    @FXML
    private TableView<Part> tableViewParts;
    @FXML
    private TableColumn<Part, Integer> inventoryLevel;

    @FXML
    private TableColumn<Part, Integer> partID;

    @FXML
    private TableColumn<Part, String> partName;

    @FXML
    private TableColumn<Part, Double> priceColumn;



    @FXML
    private TableView<Product> tableViewProducts;

    @FXML
    private TableColumn<Product, Integer> productID;

    @FXML
    private TableColumn<Product, String> productName;

    @FXML
    private TableColumn<Product, Integer> invCOL;

    @FXML
    private TableColumn<Product, Double> priceCOL;

    /**Add part to parts table in Main screen.
     * @param event add part button.
     * @throws IOException Loads FxmlLoader
     * */
    @FXML
    void OnActionAddBtn1(ActionEvent event) throws IOException {
        this.stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        this.scene = (Parent) FXMLLoader.load(this.getClass().getResource("AddPart.fxml"));
        this.stage.setScene(new Scene(this.scene));
        this.stage.show();
        

    }
    /** Add product to products table in main screen.
     * @param event add product button.
     * @throws IOException loads FXMLloader to add product screen.
     * */
    @FXML
    void OnActionAddBtn2(ActionEvent event) throws IOException {
        this.stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        this.scene = (Parent) FXMLLoader.load(this.getClass().getResource("AddProduct.fxml"));
        this.stage.setScene(new Scene(this.scene));
        this.stage.show();

    }
    /** Exit out of application from main screen.
     *
     * Alert notification shown before exiting application.
     * @param event exit button action
     * */
    @FXML
    void OnActionExitBtn(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText("Are you sure?");
        alert.setContentText(" You want to exit?");
        Optional<ButtonType> option = alert.showAndWait();
        System.exit(0);

    }
    /** Delete selected part from Parts table in main screen.
     *
     * Warning alert is displayed once user attempts to delete part.
     * alert message displays if no part is selected
     *
     * RUNTIME ERROR: Selected part was not being deleted despite alert message
     * being shown. FIX: To fix this issue I had to move Inventory.deletePart(partSelected) into an else
     * statement block after the alert message trigger.
     * @param event delete button action.
     * */
    @FXML
    void OnActionDelBtn1(ActionEvent event) {
        Part partSelected = tableViewParts.getSelectionModel().getSelectedItem();

        if (partSelected == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No part selected");
            alert.setContentText("You must select a part.");
            alert.showAndWait();
            return;


        }
        else {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText("Are you sure you want to delete?");
            alert.setContentText(" Do you choose to delete this part?");
            Optional<ButtonType> option = alert.showAndWait();

            Inventory.deletePart(partSelected);
        }

    }
    /** Delete selected product from Products table in main screen.
     *
     * Warning alert is displayed once user attempts to delete product.
     * alert message displays if no product is selected
     *
     *
     * @param event delete button action.
     * */
    @FXML
    void OnActionDeleteBtn2(ActionEvent event) {
        Product productSelected = tableViewProducts.getSelectionModel().getSelectedItem();
        

        if (productSelected == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("No part selected");
            alert.setContentText("You must select a product.");
            alert.showAndWait();
            return;


        }


        if (productSelected.getAllAssociatedParts().size() > 0) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Associated Parts Present");
                alert.setContentText("This product has associated parts and cannot delete.");
                alert.showAndWait();
                return;


            }
            else {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation");
                alert.setHeaderText("Are you sure you want to delete?");
                alert.setContentText(" Do you choose to delete this product?");
                Optional<ButtonType> option = alert.showAndWait();

                Inventory.deleteProduct(productSelected);

            }


    }


        /** Modify selected part from the parts table.
         *
         * Display error if no part is selected.
         * @param event Modify part button
         *
         * @throws IOException Loads ModifyPart screen.
         * */
        @FXML
        void OnActionModifyBtn1(ActionEvent event) throws IOException {

            try {

                Part part = tableViewParts.getSelectionModel().getSelectedItem();
                if(part !=null) {
                    int index = Inventory.getAllParts().indexOf(part);

                    FXMLLoader loader = new FXMLLoader();
                    loader.setLocation(getClass().getResource("ModifyPart.fxml"));
                    Parent root = loader.load();
                    Scene scene = new Scene(root);

                    ModifyPartController controller = loader.getController();
                    controller.getSelectedPart(part, index);


                    Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                    stage.setTitle("Modify Part");
                    stage.setScene(scene);
                    stage.show();


                } else if (part == null) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("No part selected");
                    alert.setContentText("You must select a part.");
                    alert.showAndWait();
                    return;
                }
            }
            catch (Exception e){
                e.printStackTrace();
            }


    }


    /** Modify selected product from the products table.
     *
     * Display error if no product is selected.
     * @param event Modify product button
     *
     * @throws IOException Loads ModifyProduct screen.
     * */
        @FXML
        void OnActionModifyBtn2(ActionEvent event) throws IOException {
            try {


                Product product = tableViewProducts.getSelectionModel().getSelectedItem();
                if(product !=null) {
                    int index = Inventory.getAllProducts().indexOf(product);

                    FXMLLoader loader = new FXMLLoader();
                    loader.setLocation(getClass().getResource("ModifyProduct.fxml"));
                    Parent root = loader.load();
                    Scene scene = new Scene(root);

                    ModifyProductController controller = loader.getController();
                    controller.getSelectedProduct(product, index);


                    Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                    stage.setTitle("Modify Part");
                    stage.setScene(scene);
                    stage.show();


                }
                else if (product == null) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("No product selected");
                    alert.setContentText("You must select a product.");
                    alert.showAndWait();
                    return;
                }
            }
            catch (Exception e){
                e.printStackTrace();
            }
    }
    /** Search parts in text field by part name or part ID.
     * If no value is entered an error message will be displayed.
     *
     * @param event Parts table search text field.
     * */
    @FXML
    void OnSearchPartBar(ActionEvent event) {

        if (PartsTxtFieldSearch.getText().isEmpty()) {
            System.out.println("Tests");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Failed Search");
            alert.setContentText("Enter part name or the ID number before searching");
            alert.showAndWait();
        }


        try {


        tableViewParts.setItems(Inventory.getAllParts());
        int partId = Integer.parseInt(PartsTxtFieldSearch.getText());
        Part part = Inventory.lookupPart(partId);
        tableViewParts.getSelectionModel().select(part);
        String searchBox = PartsTxtFieldSearch.getText();


    }
    catch(Exception e) {
        String partName = PartsTxtFieldSearch.getText();
        ObservableList<Part> parts = Inventory.lookupPart(partName);
        tableViewParts.setItems(parts);
    }





    }
    /** Search products in text field by part name or product ID.
     * If no value is entered an error message will be displayed.
     *
     * @param event Products table search text field.
     * */
    @FXML
    void OnSearchProductBar(ActionEvent event) {

        if (ProductsFieldTxtSearch.getText().isEmpty()) {
            System.out.println("Tests");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Failed Search");
            alert.setContentText("Enter part name or the ID number before searching");
            alert.showAndWait();
        }

        try {


            tableViewProducts.setItems(Inventory.getAllProducts());
            int productId = Integer.parseInt(ProductsFieldTxtSearch.getText());
            Product product = Inventory.lookupProduct(productId);
            tableViewProducts.getSelectionModel().select(product);
            String searchProductBox = ProductsFieldTxtSearch.getText();



        }
        catch (Exception e) {
            String productName = ProductsFieldTxtSearch.getText();
            ObservableList<Product> products = Inventory.lookupProduct(productName);
            tableViewProducts.setItems(products);

        }
    }
    /** Initialization of main screen controller and population
     * of both tables in main screen.
     *
     * @param url location of root object.
     * @param resourceBundle resources used for root object.
     * */
    public void initialize(URL url, ResourceBundle resourceBundle) {

        tableViewParts.setItems(Inventory.getAllParts());

        partID.setCellValueFactory(new PropertyValueFactory<>("id"));
        partName.setCellValueFactory(new PropertyValueFactory<>("name"));
        inventoryLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        tableViewProducts.setItems(Inventory.getAllProducts());

        productID.setCellValueFactory(new PropertyValueFactory<>("id"));
        productName.setCellValueFactory(new PropertyValueFactory<>("name"));
        invCOL.setCellValueFactory(new PropertyValueFactory<>("stock"));
        priceCOL.setCellValueFactory(new PropertyValueFactory<>("price"));

    }


}