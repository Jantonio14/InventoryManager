package inventory.inventoryparts;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import static javafx.collections.FXCollections.observableArrayList;

/** Displays inventory of both parts and products
 *
 * In this class you find data that is used throughout the app.
 *
 * @author Jacil Perez
 *
 * */

public class Inventory {

    /** observable list for parts. An observable list which allows to see all parts.
     * */
    private static ObservableList<Part> allParts = observableArrayList();
    /** observable list for products. An observable list which allows to see all products.
     * */
    private static ObservableList<Product> allProducts = observableArrayList();
    /** Adds a new part.
     * @param newPart object which adds a new part
     * */
    public static void addPart(Part newPart) {
        allParts.add(newPart);
    }
    /** Adds a new product.
     * @param newProduct object which adds a new product
     * */
    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }
    /** Searches parts list by partID.
     * @param partID ID of the part.
     * @return p The part will be returned if found by ID, otherwise null.
     * */
    public static Part lookupPart(int partID) {
        for(Part p : allParts) {
            if(p.getId() == partID)
                return  p;
        }

        return null;
    }
    /** Searches products list by productID
     * @param productID ID of the product.
     * @return p The part will be returned if found by ID, otherwise null.
     * */
    public static Product lookupProduct(int productID) {
        for(Product p : allProducts) {
            if(p.getId() == productID)
                return  p;
        }

        return null;
    }
    /** Searches parts list by name
     * @param partName name of part.
     * @return p The part will appear in search list if found by name.
     * */

    public static ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> partList = FXCollections.observableArrayList();
        for(Part p : allParts) {
            if(p.getName().contains(partName))
                partList.add(p);
        }
        if(partList.isEmpty())
            return allParts;
        return partList;
    }
    /** Searches parts list by name
     * @param productName name of product.
     * @return p The product will appear in search list if found by name.
     * */
    public static ObservableList<Product> lookupProduct(String productName) {
        ObservableList<Product> productList = FXCollections.observableArrayList();
        for(Product p : allProducts) {
            if(p.getName().contains(productName))
                productList.add(p);
        }
        if(productList.isEmpty())
            return allProducts;
        return productList;
    }
    /** Updates a part in the list
     * @param index index number of part that will be updated.
     * @param  selectedPart the part selected will be updated.
     * */
    public static void updatePart(int index, Part selectedPart) {
        allParts.set(index, selectedPart);
    }
    /** Updates a part in the list
     * @param index index number of product that will be updated.
     * @param  selectedProduct the product selected will be updated.
     * */
    public static void updateProduct(int index, Product selectedProduct) {
        allProducts.set(index, selectedProduct);
    }
    /** deletes a selected part from list.
     * @param selectedPart part that will selected for deletion.
     * @return true if part is selected or false of no part is selected.
     * */
    public static boolean deletePart (Part selectedPart) {
        if(allParts.contains(selectedPart)) {
            allParts.remove(selectedPart);
            return true;
        }
        else {
            return false;
        }
    }
    /** deletes a selected part from list.
     * @param selectedProduct product that will selected for deletion.
     * @return true if product is selected or false of no product is selected.
     * */
    public static boolean deleteProduct (Product selectedProduct) {
        if(allProducts.contains(selectedProduct)) {
            allProducts.remove(selectedProduct);
            return true;
        }
        else {
            return false;
        }
    }
    /** Getter for list of products
     * @return allProducts returns list of products.
     * */
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }
    /** Getter for list of parts
     * @return allParts returns list of parts.
     * */
    public static ObservableList<Part> getAllParts() {
        return allParts;
    }



}