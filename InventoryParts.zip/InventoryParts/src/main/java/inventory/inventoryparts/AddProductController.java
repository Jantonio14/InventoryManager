package inventory.inventoryparts;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
/**
 * This is a controller class for the Add Product screen of the application
 *
 * @author Jacil Perez
 * */
public class AddProductController implements Initializable {

    static int autoID = 3;

    @FXML
    private TableView<Part> AddProductTable;

    @FXML
    private TableColumn<Part, Integer> invCOL;

    @FXML
    private TableColumn<Part, Integer> partIDCOL;

    @FXML
    private TableColumn<Part, String> partNameCOL;

    @FXML
    private TableColumn<Part, Double> priceCOL;



    @FXML
    private TableView<Part> AddProductTable2;

    @FXML
    private TableColumn<Part, Integer> invCOL2;

    @FXML
    private TableColumn<Part, Integer> partIDCOL2;

    @FXML
    private TableColumn<Part, String> partNameCOL2;

    @FXML
    private TableColumn<Part, Double> priceCOL2;



    @FXML
    private TextField AddInvFieldTxt;

    @FXML
    private TextField AddProductIDTxt;

    @FXML
    private TextField AddProductMaxTxt;

    @FXML
    private TextField AddProductMinTxt;

    @FXML
    private TextField AddProductNameTxt;

    @FXML
    private TextField AddProductPriceFieldTxt;

    @FXML
    private TextField AddProductSearchField;
    private Stage stage;
    private Parent scene;

    private ObservableList<Part> partsAssociated = FXCollections.observableArrayList();
    /** Cancels out of the AddProduct page and returns user to MainScreen.
     * @param event Cancel event handler.
     * @throws IOException from FxmlLoader.
     * */
    @FXML
    void OnActionCancelProduct(ActionEvent event) throws IOException {
        this.stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        this.scene = (Parent) FXMLLoader.load(this.getClass().getResource("MainScreen.fxml"));
        this.stage.setScene(new Scene(this.scene));
        this.stage.show();

    }
    /** Adds selected part to associated parts table
     *
     * An error is displayed if no part is selected
     * @param event add button action
     * */
    @FXML
    void OnActionAddBtn2(ActionEvent event) {
        Part partSelected = AddProductTable.getSelectionModel().getSelectedItem();
        partsAssociated.add(partSelected);

        if (partSelected == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("please select a value!");
            alert.showAndWait();
        } else {

            AddProductTable2.setItems(partsAssociated);
        }
    }
    /** Removes selected part from associated parts table.
     * If no part is selected an error will be displayed.
     *
     * @param event remove button
     * */
    @FXML
    void OnActionRemovePart1(ActionEvent event) {
        Part partSelected = AddProductTable2.getSelectionModel().getSelectedItem();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Warning");
        alert.setContentText("Remove Associated part?");
        Optional<ButtonType> res = alert.showAndWait();


        if (res.isPresent() && res.get() == ButtonType.OK) {
            partsAssociated.remove(partSelected);

            AddProductTable2.setItems(partsAssociated);
            partIDCOL2.setCellValueFactory(new PropertyValueFactory<>("id"));
            partNameCOL2.setCellValueFactory(new PropertyValueFactory<>("name"));
            invCOL2.setCellValueFactory(new PropertyValueFactory<>("stock"));
            priceCOL2.setCellValueFactory(new PropertyValueFactory<>("price"));

        }



    }
    /** Search for specific parts within tables
     *
     * parts can be searched by name or id number
     * error message is displayed if no value is entered in field
     * and refreshes search.
     *
     * @param event search parts action
     * */

    @FXML
    void OnSearchPartBar(ActionEvent event) {
        if (AddProductSearchField.getText().isEmpty()) {
            System.out.println("Tests");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Failed Search");
            alert.setContentText("Enter part name or the ID number before searching");
            alert.showAndWait();
        }


        try {


            AddProductTable.setItems(Inventory.getAllParts());
            int partId = Integer.parseInt(AddProductSearchField.getText());
            Part part = Inventory.lookupPart(partId);
            AddProductTable.getSelectionModel().select(part);
            String searchBox = AddProductSearchField.getText();


        }
        catch(Exception e) {
            String partName = AddProductSearchField.getText();
            ObservableList<Part> parts = Inventory.lookupPart(partName);
            AddProductTable.setItems(parts);
        }



    }
    /** Adds a new product to the product table.
     * Loads main screen
     *
     * Validation is included to prevent user from entering invalid values.
     * @param event add button.
     * @throws IOException
     * */
    @FXML
    void OnActionSaveProduct(ActionEvent event) throws IOException {
        try {
            int ID = autoID++;
            int Inv = Integer.parseInt(AddInvFieldTxt.getText());

            String Name = AddProductNameTxt.getText();
            double Price = Double.parseDouble(AddProductPriceFieldTxt.getText());
            int min = Integer.parseInt(AddProductMinTxt.getText());
            int max = Integer.parseInt(AddProductMaxTxt.getText());

            if(max < min && Inv < min || Inv > max) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Inventory Error");
                alert.setContentText("Inventory amount must be within maximum and minimum range!");
                alert.showAndWait();
                return;


            }

            Product product = new Product(ID, Name, Price, Inv, min, max);

            Inventory.addProduct(product);
            for (Part part: partsAssociated) {
                if (part != partsAssociated)
                    product.addAssociatedParts(part);
            }


            this.stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            this.scene = (Parent)FXMLLoader.load(this.getClass().getResource("MainScreen.fxml"));
            this.stage.setScene(new Scene(this.scene));
            this.stage.show();

        }

        catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("please valid value for each text Field!");
            alert.showAndWait();
        }


    }
    /** Initializer for the controller.
     * Populates data into table once loaded.
     *
     * @param resourceBundle resources used for root object.
     * @param url location of root object.
     * */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {



        partIDCOL.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCOL.setCellValueFactory(new PropertyValueFactory<>("name"));
        invCOL.setCellValueFactory(new PropertyValueFactory<>("stock"));
        priceCOL.setCellValueFactory(new PropertyValueFactory<>("price"));
        AddProductTable.setItems(Inventory.getAllParts());

        partIDCOL2.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCOL2.setCellValueFactory(new PropertyValueFactory<>("name"));
        invCOL2.setCellValueFactory(new PropertyValueFactory<>("stock"));
        priceCOL2.setCellValueFactory(new PropertyValueFactory<>("price"));
    }
}

