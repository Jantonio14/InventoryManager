/** Inventory Management app
 * @author jacil
 * */
module inventory.inventoryparts {
    requires javafx.controls;
    requires javafx.fxml;


    opens inventory.inventoryparts to javafx.fxml;
    exports inventory.inventoryparts;
}